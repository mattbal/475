//
//  TakePhotoVC.swift
//  RecipeBox
//
//  Created by Matt on 12/5/22.
//

import SwiftUI
import CoreImage
import VisionKit
import CoreML
import AVFoundation

struct TakePhotoView: View {
    var body: some View {
        Text("")
    }
}

struct TakePhotoView_Previews: PreviewProvider {
    static var previews: some View {
        TakePhotoView()
    }
}
